#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#import <Security/Security.h>

#define API_CHECK_UDID   @"https://key.gmvmoba.com/udid/api/done"
#define BASE_URL         @"https://key.gmvmoba.com/connect" 
#define PROFILE_URL      @"https://key.gmvmoba.com/udid/profile"
#define ZALO_INFO        @"Chơi game vui vẻ"
#define GAME_NAME        @"PUBG" 
//-- Thay 2 link dưới = 2 link IPA của bạn trên hệ thống key.gmvmoba.com --
#define GET_KEY_URL      @"https://zalo.me/0965870531"
#define API_DYLIB_SERVER @"https://key.gmvmoba.com/api/check-bundle/gmvmoba"

static NSString *const kSavedUDID = @"GMV_UDID_DEVICE";
static UIAlertController *_currentUpdateAlert = nil; 

static NSString * GetCurrentBID() { return [[NSBundle mainBundle] bundleIdentifier] ?: @"com.gmv.unknown"; }
static NSString * PrivateAccount() { return [NSString stringWithFormat:@"GMV_PV_%@", GetCurrentBID()]; }
static NSString * TrackingAccount(NSString *userKey) { return [NSString stringWithFormat:@"GMV_TRK_%@", userKey]; }

@interface RotateViewController : UIViewController @end
@implementation RotateViewController
- (BOOL)shouldAutorotate { return YES; }
- (UIInterfaceOrientationMask)supportedInterfaceOrientations { return UIInterfaceOrientationMaskLandscape; }
- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation { return UIInterfaceOrientationLandscapeRight; }
@end

@interface KeyManager : NSObject
@property (nonatomic, strong) UIWindow *alertWindow;
@property (nonatomic, strong) UIVisualEffectView *blurView; 
@property (nonatomic, assign) BOOL isChecking; 
@property (nonatomic, assign) BOOL isDialogVisible; 
@property (nonatomic, assign) BOOL hasShownUpdate;
@property (nonatomic, strong) NSTimer *updateCheckTimer; 
+ (instancetype)shared;
@end

@implementation KeyManager

+ (instancetype)shared {
    static KeyManager *shared = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{ shared = [[KeyManager alloc] init]; });
    return shared;
}

+ (void)startUpdatePolling {
    if ([KeyManager shared].updateCheckTimer) return;
    [KeyManager shared].updateCheckTimer = [NSTimer scheduledTimerWithTimeInterval:5.0 
                                                                             target:self 
                                                                           selector:@selector(checkUpdateFirst) 
                                                                           userInfo:nil 
                                                                            repeats:YES];
}

+ (void)checkUpdateFirst {
    if ([KeyManager shared].isChecking) return;
    [KeyManager shared].isChecking = YES;

    NSString *urlStr = [NSString stringWithFormat:@"%@?bid=%@&name=%@", API_DYLIB_SERVER, GetCurrentBID(), GAME_NAME];
    NSURLRequest *req = [NSURLRequest requestWithURL:[NSURL URLWithString:urlStr] 
                                         cachePolicy:NSURLRequestReloadIgnoringLocalCacheData 
                                     timeoutInterval:8];
                                     
    [[[NSURLSession sharedSession] dataTaskWithRequest:req completionHandler:^(NSData *data, NSURLResponse *res, NSError *err) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [KeyManager shared].isChecking = NO;
            if (data) {
                NSDictionary *json = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
                BOOL forceUpdate = [json[@"force_update"] boolValue];

                if (forceUpdate) {
                    if (![KeyManager shared].hasShownUpdate) {
                        [KeyManager shared].hasShownUpdate = YES;
                        [self showForceUpdateAlert:json[@"update_link"] message:json[@"update_msg"]];
                    }
                } else {
                    if ([KeyManager shared].hasShownUpdate) {
                        [KeyManager shared].hasShownUpdate = NO;
                        if (_currentUpdateAlert) {
                            [_currentUpdateAlert dismissViewControllerAnimated:YES completion:^{
                                _currentUpdateAlert = nil;
                                [self setBlurActive:NO];
                                [KeyManager shared].alertWindow.hidden = YES;
                                [KeyManager shared].isDialogVisible = NO;
                                [self checkDeviceAndStart];
                            }];
                        }
                    }
                }
            }
            
            static dispatch_once_t onceStart;
            dispatch_once(&onceStart, ^{
                if (![KeyManager shared].hasShownUpdate) [self checkDeviceAndStart];
            });
        });
    }] resume];
}

+ (void)showForceUpdateAlert:(NSString *)link message:(NSString *)msg {
    [self prepareWindow];
    [KeyManager shared].alertWindow.hidden = NO;
    [self setBlurActive:YES];
    [KeyManager shared].isDialogVisible = YES;

    [[KeyManager shared].alertWindow.rootViewController dismissViewControllerAnimated:NO completion:nil];

    _currentUpdateAlert = [UIAlertController alertControllerWithTitle:@"🚀 Bảo Trì 🚀" 
                                                              message:msg 
                                                       preferredStyle:UIAlertControllerStyleAlert];
    
    [_currentUpdateAlert addAction:[UIAlertAction actionWithTitle:@"Cập Nhật" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *action) {
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:link] options:@{} completionHandler:nil];
    }]];
    
    [[KeyManager shared].alertWindow.rootViewController presentViewController:_currentUpdateAlert animated:YES completion:nil];
}


+ (void)checkDeviceAndStart {
    if ([KeyManager shared].isChecking) return;
    [KeyManager shared].isChecking = YES;

    NSURLRequest *req = [NSURLRequest requestWithURL:[NSURL URLWithString:API_CHECK_UDID] cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:10];
    [[[NSURLSession sharedSession] dataTaskWithRequest:req completionHandler:^(NSData *data, NSURLResponse *res, NSError *err) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [KeyManager shared].isChecking = NO;
            if (data) {
                NSDictionary *json = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
                if ([json[@"status"] boolValue] && json[@"udid"]) {
                    [[NSUserDefaults standardUserDefaults] setObject:json[@"udid"] forKey:kSavedUDID];
                    [[NSUserDefaults standardUserDefaults] synchronize];
                    
                    NSString *storedKey = [self getPermanentKey];
                    if (storedKey) [self verifyKey:storedKey]; 
                    else [self showMainAlert:nil];
                    return;
                }
            }
            [self showGetUDIDAlert];
        });
    }] resume];
}

+ (void)verifyKey:(NSString *)userKey {
    NSString *bindingBID = [self getBindingBIDForKey:userKey];
    if (bindingBID && ![bindingBID isEqualToString:GetCurrentBID()]) {
        [self showToast:@"⛔ Key không hợp lệ"];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 1.8 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{ [self showMainAlert:userKey]; });
        return;
    }

    NSString *udid = [[NSUserDefaults standardUserDefaults] objectForKey:kSavedUDID] ?: @"UNKNOWN";
    NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:BASE_URL]];
    req.HTTPMethod = @"POST";
    NSString *params = [NSString stringWithFormat:@"game=%@&user_key=%@&serial=%@", GAME_NAME, userKey, udid];
    req.HTTPBody = [params dataUsingEncoding:NSUTF8StringEncoding];
    
    [[[NSURLSession sharedSession] dataTaskWithRequest:req completionHandler:^(NSData *data, NSURLResponse *res, NSError *err) {
        dispatch_async(dispatch_get_main_queue(), ^{
            if (!data) { [self showToast:@"⛔ Lỗi kết nối!"]; [self showMainAlert:userKey]; return; }
            NSDictionary *json = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
            if ([json[@"status"] boolValue]) {
                [self savePermanentKey:userKey];
                [self showToast:[NSString stringWithFormat:@"✅ Thành Công!\nHạn: %@", json[@"data"][@"EXP"]]];
                
                static BOOL isMenuStarted = NO;
                if (!isMenuStarted) {
                    // [YourMenuClass startMenu];
                    isMenuStarted = YES;
                }

                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 1.6 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
                    [KeyManager shared].alertWindow.hidden = YES;
                    [KeyManager shared].isDialogVisible = NO;
                    [self setBlurActive:NO];
                });
            } else {
                [self showToast:@"⛔ Key không hợp lệ"];
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 1.8 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{ [self showMainAlert:userKey]; });
            }
        });
    }] resume];
}

+ (NSString *)getBindingBIDForKey:(NSString *)key {
    NSDictionary *query = @{(__bridge id)kSecClass: (__bridge id)kSecClassGenericPassword, (__bridge id)kSecAttrAccount: TrackingAccount(key), (__bridge id)kSecReturnData: @YES, (__bridge id)kSecMatchLimit: (__bridge id)kSecMatchLimitOne};
    CFTypeRef dataRef = NULL;
    if (SecItemCopyMatching((__bridge CFDictionaryRef)query, &dataRef) == errSecSuccess) {
        NSData *data = (__bridge_transfer NSData *)dataRef;
        return [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    }
    return nil;
}

+ (void)savePermanentKey:(NSString *)key {
    if (!key) return;
    NSData *keyData = [key dataUsingEncoding:NSUTF8StringEncoding];
    NSData *bidData = [GetCurrentBID() dataUsingEncoding:NSUTF8StringEncoding];
    NSDictionary *pQ = @{(__bridge id)kSecClass: (__bridge id)kSecClassGenericPassword, (__bridge id)kSecAttrAccount: PrivateAccount()};
    SecItemDelete((__bridge CFDictionaryRef)pQ);
    NSMutableDictionary *p = [pQ mutableCopy]; [p setObject:keyData forKey:(__bridge id)kSecValueData];
    SecItemAdd((__bridge CFDictionaryRef)p, NULL);
    NSDictionary *tQ = @{(__bridge id)kSecClass: (__bridge id)kSecClassGenericPassword, (__bridge id)kSecAttrAccount: TrackingAccount(key)};
    SecItemDelete((__bridge CFDictionaryRef)tQ);
    NSMutableDictionary *t = [tQ mutableCopy]; [t setObject:bidData forKey:(__bridge id)kSecValueData];
    SecItemAdd((__bridge CFDictionaryRef)t, NULL);
}

+ (NSString *)getPermanentKey {
    NSDictionary *query = @{(__bridge id)kSecClass: (__bridge id)kSecClassGenericPassword, (__bridge id)kSecAttrAccount: PrivateAccount(), (__bridge id)kSecReturnData: @YES, (__bridge id)kSecMatchLimit: (__bridge id)kSecMatchLimitOne};
    CFTypeRef dataRef = NULL;
    if (SecItemCopyMatching((__bridge CFDictionaryRef)query, &dataRef) == errSecSuccess) {
        NSData *data = (__bridge_transfer NSData *)dataRef;
        return [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    }
    return nil;
}

+ (void)showToast:(NSString *)message {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self prepareWindow];
        [KeyManager shared].alertWindow.hidden = NO;
        UIAlertController *toast = [UIAlertController alertControllerWithTitle:nil message:message preferredStyle:UIAlertControllerStyleAlert];
        [[KeyManager shared].alertWindow.rootViewController presentViewController:toast animated:YES completion:nil];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ 
            [toast dismissViewControllerAnimated:YES completion:nil]; 
        });
    });
}

+ (void)setBlurActive:(BOOL)active {
    [UIView animateWithDuration:0.3 animations:^{
        [KeyManager shared].blurView.alpha = active ? 1.0 : 0.0;
    }];
}

+ (void)showGetUDIDAlert {
    dispatch_async(dispatch_get_main_queue(), ^{
        if ([KeyManager shared].isDialogVisible) return;
        [self prepareWindow];
        [KeyManager shared].alertWindow.hidden = NO;
        [self setBlurActive:YES];
        [KeyManager shared].isDialogVisible = YES;

        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"XÁC MINH UDID" message:@"Vui lòng 'Click Lấy UDID' cài đặt hồ sơ để xác minh thiết bị." preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:@"Click Lấy UDID (Safari)" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *action) {
            [KeyManager shared].isDialogVisible = NO;
            [self setBlurActive:NO];
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:PROFILE_URL] options:@{} completionHandler:nil];
        }]];
        [[KeyManager shared].alertWindow.rootViewController presentViewController:alert animated:YES completion:nil];
    });
}

+ (void)showMainAlert:(NSString *)initialKey {
    dispatch_async(dispatch_get_main_queue(), ^{
        if ([KeyManager shared].isDialogVisible) return;
        [self prepareWindow];
        [KeyManager shared].alertWindow.hidden = NO;
        [self setBlurActive:YES];
        [KeyManager shared].isDialogVisible = YES;

        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Đăng Nhập" message:nil preferredStyle:UIAlertControllerStyleAlert];
        NSString *msg = ZALO_INFO;
        NSMutableAttributedString *attrMsg = [[NSMutableAttributedString alloc] initWithString:msg];
        [attrMsg addAttribute:NSForegroundColorAttributeName value:[UIColor systemRedColor] range:NSMakeRange(0, msg.length)];
        [alert setValue:attrMsg forKey:@"attributedMessage"];

        [alert addTextFieldWithConfigurationHandler:^(UITextField *textField) {
            textField.placeholder = @"Dán key vào đây...";
            textField.textAlignment = NSTextAlignmentCenter;
            textField.text = initialKey ?: [self getPermanentKey]; 
            
            UIButton *pasteBtn = [UIButton buttonWithType:UIButtonTypeSystem];
            [pasteBtn setTitle:@"Dán" forState:UIControlStateNormal];
            pasteBtn.frame = CGRectMake(0, 0, 45, 30);
            [pasteBtn addTarget:self action:@selector(handlePaste:) forControlEvents:UIControlEventTouchUpInside];
            textField.rightView = pasteBtn;
            textField.rightViewMode = UITextFieldViewModeAlways;
            objc_setAssociatedObject(pasteBtn, "targetField", textField, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        }];

        [alert addAction:[UIAlertAction actionWithTitle:@"Mua Key" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            [KeyManager shared].isDialogVisible = NO;
            [self setBlurActive:NO];
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:GET_KEY_URL] options:@{} completionHandler:nil];
        }]];

        [alert addAction:[UIAlertAction actionWithTitle:@"Check Key" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) { 
            [KeyManager shared].isDialogVisible = NO;
            [self setBlurActive:NO];
            [self verifyKey:alert.textFields.firstObject.text]; 
        }]];
        [[KeyManager shared].alertWindow.rootViewController presentViewController:alert animated:YES completion:nil];
    });
}

+ (void)handlePaste:(UIButton *)sender {
    UITextField *t = (UITextField *)objc_getAssociatedObject(sender, "targetField");
    if (t) t.text = [UIPasteboard generalPasteboard].string;
}

+ (void)prepareWindow {
    if (![KeyManager shared].alertWindow) {
        [KeyManager shared].alertWindow = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
        [KeyManager shared].alertWindow.windowLevel = UIWindowLevelStatusBar + 999.0;
        [KeyManager shared].alertWindow.rootViewController = [RotateViewController new];
        [KeyManager shared].alertWindow.backgroundColor = [UIColor clearColor];

        UIBlurEffect *blurEffect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleDark];
        [KeyManager shared].blurView = [[UIVisualEffectView alloc] initWithEffect:blurEffect];
        [KeyManager shared].blurView.frame = [KeyManager shared].alertWindow.bounds;
        [KeyManager shared].blurView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        [KeyManager shared].blurView.alpha = 0.0;
        [[KeyManager shared].alertWindow.rootViewController.view addSubview:[KeyManager shared].blurView];

        if (@available(iOS 13.0, *)) {
            for (UIWindowScene *scene in [UIApplication sharedApplication].connectedScenes) {
                if (scene.activationState == UISceneActivationStateForegroundActive) {
                    [KeyManager shared].alertWindow.windowScene = scene; break;
                }
            }
        }
    }
}

+ (void)load {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 1.2 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
            [self checkUpdateFirst]; 
            [self startUpdatePolling];
        });
        
        [[NSNotificationCenter defaultCenter] addObserverForName:UIApplicationDidBecomeActiveNotification object:nil queue:[NSOperationQueue mainQueue] usingBlock:^(NSNotification *note) {
             [self checkUpdateFirst];
        }];
    });
}
@end
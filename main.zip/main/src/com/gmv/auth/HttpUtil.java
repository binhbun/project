package com.gmv.auth;

import java.io.*;
import java.net.*;

public class HttpUtil {

    public static String post(
    String url,
    String data){

        try{

            URL u = new URL(url);

            HttpURLConnection c =
            (HttpURLConnection)
            u.openConnection();

            c.setRequestMethod("POST");
            c.setDoOutput(true);

            OutputStream os =
            c.getOutputStream();

            os.write(data.getBytes());
            os.flush();
            os.close();

            BufferedReader br =
            new BufferedReader(
            new InputStreamReader(
            c.getInputStream()));

            String line;
            StringBuilder res =
            new StringBuilder();

            while((line = br.readLine()) != null){
                res.append(line);
            }

            br.close();

            return res.toString();

        }catch(Exception e){
            return null;
        }

    }

}
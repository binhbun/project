package com.gmv.auth;

import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.*;
import android.content.*;
import android.net.Uri;
import android.graphics.Color;
import org.json.JSONObject;

public class MainActivity { 

    static String GAME = "PUBG";
    static String PREF_NAME = "AUTH_PREF";
    static String KEY_STORAGE = "last_key";

    public static void showKeyDialog(final Context ctx) {
        
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                final SharedPreferences pref = ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
                String savedKey = pref.getString(KEY_STORAGE, "");

                final EditText keyBox = new EditText(ctx);
                keyBox.setHint("Nhập Key tại đây");
                keyBox.setText(savedKey);

                LinearLayout layout = new LinearLayout(ctx);
                layout.setOrientation(LinearLayout.VERTICAL);
                layout.setPadding(40, 20, 40, 20);

                LinearLayout row = new LinearLayout(ctx);
                row.setOrientation(LinearLayout.HORIZONTAL);

                Button paste = new Button(ctx);
                paste.setText("Dán");

                row.addView(keyBox, new LinearLayout.LayoutParams(0, -2, 1));
                row.addView(paste);

                final TextView status = new TextView(ctx);
                layout.addView(row);
                layout.addView(status);

                AlertDialog.Builder d = new AlertDialog.Builder(ctx);
                d.setTitle("KEY LOGIN");
                d.setView(layout);
                d.setCancelable(false);

                d.setPositiveButton("LOGIN", null);
                d.setNeutralButton("GET KEY", null);

                final AlertDialog dialog = d.create();
                
                dialog.show();

                dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://key.gmvmoba.com/gmvmoba/getkey"));
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        ctx.startActivity(intent);
                    }
                });

                paste.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        ClipboardManager cm = (ClipboardManager) ctx.getSystemService(Context.CLIPBOARD_SERVICE);
                        if (cm != null && cm.hasPrimaryClip()) {
                            keyBox.setText(cm.getPrimaryClip().getItemAt(0).getText());
                        }
                    }
                });

                final Button loginBtn = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
                loginBtn.setOnClickListener(new View.OnClickListener() {
                    public void onClick(final View v) {
                        final String key = keyBox.getText().toString().trim();

                        if (key.isEmpty()) {
                            status.setText("Nhập KEY");
                            status.setTextColor(Color.RED);
                            return;
                        }

                        status.setText("Checking key...");
                        loginBtn.setEnabled(false);

                        new Thread(new Runnable() {
                            public void run() {
                                final JSONObject j = KeyAuth.check(ctx, key, GAME);

                                new Handler(Looper.getMainLooper()).post(new Runnable() {
                                    public void run() {
                                        loginBtn.setEnabled(true);
                                        if (j == null) {
                                            status.setText("Server error");
                                            return;
                                        }

                                        if (j.optBoolean("status", false)) {
                                            pref.edit().putString(KEY_STORAGE, key).apply();
                                            JSONObject data = j.optJSONObject("data");
                                            String exp = data != null ? data.optString("EXP", "Unknown") : "Unknown";
                                            Toast.makeText(ctx, "Thành công: " + exp, Toast.LENGTH_LONG).show();
                                            dialog.dismiss();
                                            
                                        } else {
                                            status.setText(j.optString("reason", "KEY INVALID"));
                                            status.setTextColor(Color.RED);
                                        }
                                    }
                                });
                            }
                        }).start();
                    }
                });

                if (!savedKey.isEmpty()) {
                    loginBtn.performClick();
                }
            }
        });
    }
}
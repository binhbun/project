package com.gmv.auth;

import android.content.Context;
import android.provider.Settings;

public class DeviceUtil {

    public static String getSerial(
    Context ctx){

        try{

            return Settings.Secure.getString(
            ctx.getContentResolver(),
            Settings.Secure.ANDROID_ID);

        }catch(Exception e){

            return "unknown";

        }

    }

}
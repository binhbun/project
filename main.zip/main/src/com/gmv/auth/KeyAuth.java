package com.gmv.auth;

import android.content.Context;
import android.provider.Settings;
import org.json.JSONObject;
import java.net.*;
import java.io.*;
import java.security.MessageDigest;

public class KeyAuth {

    static String API = "https://key.gmvmoba.com/connect";
    
    static String STATIC_WORDS = "Vm8Lk7Uj2JmsjCPVPVjrLa7zgfx3uz9E";

    public static JSONObject check(Context ctx, String key, String game) {
        try {
            String device = Settings.Secure.getString(ctx.getContentResolver(), Settings.Secure.ANDROID_ID);
            if (device == null) device = "unknown";

            String postData = "game=" + URLEncoder.encode(game, "UTF-8") +
                              "&user_key=" + URLEncoder.encode(key, "UTF-8") +
                              "&serial=" + URLEncoder.encode(device, "UTF-8");

            String res = post(API, postData);
            if (res == null || res.isEmpty()) return null;

            JSONObject j = new JSONObject(res.trim());
            boolean ok = j.optBoolean("status", false);

            if (!ok) return j;

            JSONObject data = j.optJSONObject("data");
            if (data == null) return null;

            String tokenServer = data.optString("token", "");
            
            String salt = game + "-" + key + "-" + device + "-" + STATIC_WORDS;
            String tokenLocal = md5(salt);

            if (!tokenLocal.equalsIgnoreCase(tokenServer)) {
                JSONObject fake = new JSONObject();
                fake.put("status", false);
                fake.put("reason", "PHÁT HIỆN THAY ĐỔI DỮ LIỆU\n(Token Mismatch)");
                return fake;
            }

            return j;

        } catch (Exception e) {
            return null;
        }
    }

    private static String post(String urlStr, String data) {
        try {
            URL u = new URL(urlStr);
            HttpURLConnection c = (HttpURLConnection) u.openConnection();
            c.setRequestMethod("POST");
            c.setConnectTimeout(15000);
            c.setReadTimeout(15000);
            c.setDoOutput(true);

            c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

            OutputStream os = c.getOutputStream();
            os.write(data.getBytes("UTF-8"));
            os.flush();
            os.close();

            InputStream is = (c.getResponseCode() < 400) ? c.getInputStream() : c.getErrorStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
            br.close();
            return sb.toString();
        } catch (Exception e) {
            return null;
        }
    }

    private static String md5(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] b = md.digest(s.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte x : b) {
                sb.append(String.format("%02x", x));
            }
            return sb.toString();
        } catch (Exception e) {
            return "";
        }
    }
}